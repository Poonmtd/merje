/*----- ไว้เปลี่ยนหน้าถ้าไ button เอาปชไ้ะะ -------*/
function openPage(pageUrl){
       window.location.href=pageUrl;
     }



      function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
      
  
    